import mongoose from "mongoose";

export async function connectDatabase(uri) {
  if (!uri) throw new Error("MONGODB_URI is required");
  await mongoose.connect(uri);
  console.log('connected to db')
}
